export class Client {
  id?: string;
  firstname: string;
  lastname: string;
  email: string;
  telephoneNumber: string;
  companyName: string;
}
